package com.medsim.app.ui.screens.surgery

import androidx.lifecycle.ViewModel
import com.medsim.app.data.SurgeryRepository
import com.medsim.app.data.models.SurgeryAttemptResult
import com.medsim.app.data.models.SurgeryChoice
import com.medsim.app.data.models.SurgeryProcedure
import com.medsim.app.data.models.SurgeryStepOutcome
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SurgeryUiState(
    val procedure: SurgeryProcedure? = null,
    val currentStepIndex: Int = 0,
    val outcomes: List<SurgeryStepOutcome> = emptyList(),
    val lastFeedback: String? = null,
    val lastChoiceWasCorrect: Boolean? = null,
    val finished: Boolean = false,
    val result: SurgeryAttemptResult? = null
)

class SurgeryViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(SurgeryUiState())
    val uiState: StateFlow<SurgeryUiState> = _uiState.asStateFlow()

    fun loadProcedure(procedureId: String) {
        val procedure = SurgeryRepository.getById(procedureId) ?: return
        _uiState.value = SurgeryUiState(procedure = procedure)
    }

    /** Called when the student taps a choice for the current step. */
    fun chooseOption(choice: SurgeryChoice) {
        val state = _uiState.value
        val procedure = state.procedure ?: return
        if (state.lastFeedback != null || state.finished) return // already answered this step, waiting to advance

        val step = procedure.steps[state.currentStepIndex]
        val outcome = SurgeryStepOutcome(
            step = step,
            choiceLabel = choice.label,
            wasCorrect = choice.isCorrect,
            pointsEarned = choice.pointsIfChosen
        )

        _uiState.value = state.copy(
            outcomes = state.outcomes + outcome,
            lastFeedback = choice.feedback,
            lastChoiceWasCorrect = choice.isCorrect
        )
    }

    /** Advance to the next step, or finish the case and compute the final result. */
    fun advance() {
        val state = _uiState.value
        val procedure = state.procedure ?: return
        val nextIndex = state.currentStepIndex + 1

        if (nextIndex >= procedure.steps.size) {
            val totalScore = state.outcomes.sumOf { it.pointsEarned }.coerceAtLeast(0)
            val maxScore = procedure.steps.sumOf { step -> step.choices.maxOf { it.pointsIfChosen } }
            _uiState.value = state.copy(
                finished = true,
                lastFeedback = null,
                result = SurgeryAttemptResult(
                    procedure = procedure,
                    outcomes = state.outcomes,
                    totalScore = totalScore,
                    maxScore = maxScore
                )
            )
        } else {
            _uiState.value = state.copy(
                currentStepIndex = nextIndex,
                lastFeedback = null,
                lastChoiceWasCorrect = null
            )
        }
    }

    fun reset(procedureId: String) {
        loadProcedure(procedureId)
    }
}
