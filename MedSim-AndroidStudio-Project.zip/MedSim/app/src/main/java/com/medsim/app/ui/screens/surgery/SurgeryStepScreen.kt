package com.medsim.app.ui.screens.surgery

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurgeryStepScreen(
    procedureId: String,
    onBack: () -> Unit,
    viewModel: SurgeryViewModel = viewModel()
) {
    LaunchedEffect(procedureId) { viewModel.loadProcedure(procedureId) }
    val state by viewModel.uiState.collectAsState()
    val procedure = state.procedure ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(procedure.title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            if (state.finished) {
                SurgeryResultView(state, onRetry = { viewModel.reset(procedureId) })
            } else {
                val step = procedure.steps[state.currentStepIndex]
                LinearProgressIndicator(
                    progress = { (state.currentStepIndex).toFloat() / procedure.steps.size },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Step ${step.stepNumber} of ${procedure.steps.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(Modifier.height(8.dp))

                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(step.emojiIcon, style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(step.instruction, style = MaterialTheme.typography.titleMedium)
                    }
                }

                Spacer(Modifier.height(16.dp))

                if (state.lastFeedback == null) {
                    step.choices.forEach { choice ->
                        Button(
                            onClick = { viewModel.chooseOption(choice) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(choice.label)
                        }
                    }
                } else {
                    val correct = state.lastChoiceWasCorrect == true
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (correct)
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                            else
                                MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                if (correct) "Good call" else "Not ideal",
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(state.lastFeedback ?: "")
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { viewModel.advance() }, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            if (state.currentStepIndex + 1 >= procedure.steps.size)
                                "Finish Procedure"
                            else
                                "Continue"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SurgeryResultView(state: SurgeryUiState, onRetry: () -> Unit) {
    val result = state.result ?: return
    val passed = result.totalScore >= (result.maxScore * 0.7).toInt()

    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                if (passed) "Procedure Completed Successfully" else "Procedure Completed — Room for Improvement",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text("Score: ${result.totalScore} / ${result.maxScore}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(if (passed) result.procedure.successSummary else result.procedure.complicationSummary)
            Spacer(Modifier.height(16.dp))
            Text("Step-by-step feedback", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            result.outcomes.forEachIndexed { index, outcome ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (outcome.wasCorrect)
                                Color(0xFF2E7D32).copy(alpha = 0.08f)
                            else
                                Color(0xFFC62828).copy(alpha = 0.08f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(10.dp)
                ) {
                    Text("Step ${index + 1}: ${outcome.choiceLabel}", fontWeight = FontWeight.Medium)
                    Text("Points: ${outcome.pointsEarned}", style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                Text("Retry Procedure")
            }
        }
    }
}
