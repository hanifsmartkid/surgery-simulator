package com.medsim.app.ui.screens.diagnosis

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosisCaseScreen(
    caseId: String,
    onBack: () -> Unit,
    viewModel: DiagnosisViewModel = viewModel()
) {
    LaunchedEffect(caseId) { viewModel.loadCase(caseId) }
    val state by viewModel.uiState.collectAsState()
    val case = state.case ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(case.title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionCard(title = "Patient") {
                    Text("${case.patient.name} — ${case.patient.age}yo ${case.patient.gender}")
                    Spacer(Modifier.height(6.dp))
                    Text("Chief complaint: ${case.patient.chiefComplaint}", fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text(case.patient.historyOfPresentIllness)
                    Spacer(Modifier.height(6.dp))
                    Text("PMH: ${case.patient.pastMedicalHistory}", style = MaterialTheme.typography.bodyMedium)
                }
            }

            item {
                SectionCard(title = "Vitals") {
                    val v = case.patient.vitals
                    Text("Temp: ${v.temperatureC}   HR: ${v.heartRateBpm}   BP: ${v.bloodPressure}")
                    Text("RR: ${v.respiratoryRate}   SpO2: ${v.spo2}")
                }
            }

            item {
                SectionCard(title = "Physical Exam") {
                    case.physicalExamFindings.forEach { finding ->
                        Text("• $finding")
                    }
                }
            }

            item {
                SectionCard(title = "Order Tests") {
                    Text(
                        "Tap to order. Essential tests earn points; unnecessary tests cost a small penalty.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Spacer(Modifier.height(8.dp))
                    case.availableTests.forEach { test ->
                        val ordered = state.orderedTestIds.contains(test.id)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(
                                    if (ordered) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent,
                                    RoundedCornerShape(8.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickableRow { viewModel.toggleTest(test.id) }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(test.name, fontWeight = FontWeight.Medium)
                                Text(if (ordered) "Ordered ✓" else "Order")
                            }
                            if (ordered) {
                                Text(
                                    text = "Result: ${test.resultText}",
                                    modifier = Modifier.padding(start = 10.dp, bottom = 8.dp, end = 10.dp),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }

            item {
                SectionCard(title = "Your Diagnosis") {
                    state.shuffledDifferentials.forEach { option ->
                        val selected = state.selectedDiagnosis == option
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickableRow { viewModel.selectDiagnosis(option) }
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(10.dp)
                        ) {
                            Text(option, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.submit() },
                        enabled = state.selectedDiagnosis != null && !state.submitted,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Submit Diagnosis")
                    }
                }
            }

            state.result?.let { result ->
                item {
                    SectionCard(title = if (result.wasCorrect) "Correct!" else "Not Quite") {
                        Text("Correct diagnosis: ${result.case.correctDiagnosis}")
                        Spacer(Modifier.height(6.dp))
                        Text("Score: ${result.score} / ${result.maxScore}", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Text("Teaching Points", fontWeight = FontWeight.SemiBold)
                        result.case.teachingPoints.forEach { Text("• $it") }
                        if (result.case.redFlags.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Text("Red Flags", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                            result.case.redFlags.forEach { Text("• $it") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { viewModel.reset(caseId) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Retry Case")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

// Small helper to keep Row clickable without importing clickable everywhere above.
private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
