package com.medsim.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.medsim.app.ui.screens.diagnosis.DiagnosisCaseScreen
import com.medsim.app.ui.screens.diagnosis.DiagnosisListScreen
import com.medsim.app.ui.screens.home.HomeScreen
import com.medsim.app.ui.screens.surgery.SurgeryListScreen
import com.medsim.app.ui.screens.surgery.SurgeryStepScreen

object Routes {
    const val HOME = "home"
    const val DIAGNOSIS_LIST = "diagnosis_list"
    const val DIAGNOSIS_CASE = "diagnosis_case/{caseId}"
    const val SURGERY_LIST = "surgery_list"
    const val SURGERY_STEP = "surgery_step/{procedureId}"

    fun diagnosisCase(caseId: String) = "diagnosis_case/$caseId"
    fun surgeryStep(procedureId: String) = "surgery_step/$procedureId"
}

@Composable
fun MedSimNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onOpenDiagnosis = { navController.navigate(Routes.DIAGNOSIS_LIST) },
                onOpenSurgery = { navController.navigate(Routes.SURGERY_LIST) }
            )
        }

        composable(Routes.DIAGNOSIS_LIST) {
            DiagnosisListScreen(
                onBack = { navController.popBackStack() },
                onSelectCase = { caseId -> navController.navigate(Routes.diagnosisCase(caseId)) }
            )
        }

        composable(
            route = Routes.DIAGNOSIS_CASE,
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) { backStackEntry ->
            val caseId = backStackEntry.arguments?.getString("caseId") ?: return@composable
            DiagnosisCaseScreen(
                caseId = caseId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SURGERY_LIST) {
            SurgeryListScreen(
                onBack = { navController.popBackStack() },
                onSelectProcedure = { procedureId -> navController.navigate(Routes.surgeryStep(procedureId)) }
            )
        }

        composable(
            route = Routes.SURGERY_STEP,
            arguments = listOf(navArgument("procedureId") { type = NavType.StringType })
        ) { backStackEntry ->
            val procedureId = backStackEntry.arguments?.getString("procedureId") ?: return@composable
            SurgeryStepScreen(
                procedureId = procedureId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
