package com.medsim.app.data.models

/**
 * One decision point in an operation. The student picks the correct next
 * action/instrument from a set of choices. Wrong choices trigger a
 * complication message and a point penalty but do not necessarily end the case,
 * mirroring how real training simulators let you recover from small errors.
 */
data class SurgeryStep(
    val id: String,
    val stepNumber: Int,
    val instruction: String,
    val emojiIcon: String, // simple visual cue for the step (placeholder for real art/animation)
    val choices: List<SurgeryChoice>,
    val timeLimitSeconds: Int? = null // optional, for steps where speed matters (e.g. hemorrhage control)
)

data class SurgeryChoice(
    val label: String,
    val isCorrect: Boolean,
    val feedback: String,
    val pointsIfChosen: Int
)

data class SurgeryProcedure(
    val id: String,
    val title: String,
    val specialty: String,
    val difficulty: Difficulty,
    val briefing: String,
    val patientContext: String,
    val steps: List<SurgeryStep>,
    val successSummary: String,
    val complicationSummary: String
)

data class SurgeryStepOutcome(
    val step: SurgeryStep,
    val choiceLabel: String,
    val wasCorrect: Boolean,
    val pointsEarned: Int
)

data class SurgeryAttemptResult(
    val procedure: SurgeryProcedure,
    val outcomes: List<SurgeryStepOutcome>,
    val totalScore: Int,
    val maxScore: Int
)
