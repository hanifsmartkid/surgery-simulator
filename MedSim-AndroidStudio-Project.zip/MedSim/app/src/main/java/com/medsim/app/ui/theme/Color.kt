package com.medsim.app.ui.theme

import androidx.compose.ui.graphics.Color

val MedBlue = Color(0xFF1565C0)
val MedBlueDark = Color(0xFF0D47A1)
val MedTeal = Color(0xFF00897B)
val MedRed = Color(0xFFC62828)
val MedGreen = Color(0xFF2E7D32)
val MedBackground = Color(0xFFF5F7FA)
val MedSurface = Color(0xFFFFFFFF)
val MedOnSurface = Color(0xFF1B1F23)
