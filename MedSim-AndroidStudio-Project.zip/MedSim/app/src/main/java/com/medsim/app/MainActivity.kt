package com.medsim.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.medsim.app.ui.navigation.MedSimNavGraph
import com.medsim.app.ui.theme.MedSimTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MedSimApp()
        }
    }
}

@Composable
fun MedSimApp() {
    MedSimTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            MedSimNavGraph()
        }
    }
}
