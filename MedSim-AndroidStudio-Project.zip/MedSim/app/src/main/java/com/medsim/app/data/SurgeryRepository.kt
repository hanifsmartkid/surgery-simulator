package com.medsim.app.data

import com.medsim.app.data.models.*

object SurgeryRepository {

    val procedures: List<SurgeryProcedure> = listOf(
        SurgeryProcedure(
            id = "lap_appendectomy",
            title = "Laparoscopic Appendectomy",
            specialty = "General Surgery",
            difficulty = Difficulty.EASY,
            briefing = "22-year-old male, confirmed acute appendicitis on imaging. Proceeding to " +
                "laparoscopic appendectomy under general anesthesia.",
            patientContext = "Patient positioned supine, prepped and draped. Pneumoperitoneum established.",
            steps = listOf(
                SurgeryStep(
                    id = "step1",
                    stepNumber = 1,
                    instruction = "Select the initial access technique to establish pneumoperitoneum.",
                    emojiIcon = "🔍",
                    choices = listOf(
                        SurgeryChoice("Veress needle at umbilicus", true, "Correct — a common, safe entry point away from prior scars.", 10),
                        SurgeryChoice("Direct trocar insertion at McBurney's point", false, "Risky as a first entry point without confirmed pneumoperitoneum — increases risk of visceral injury.", -5),
                        SurgeryChoice("Open (Hasson) technique at the umbilicus", true, "Also acceptable — a safe alternative, especially in patients with prior surgeries.", 10)
                    )
                ),
                SurgeryStep(
                    id = "step2",
                    stepNumber = 2,
                    instruction = "Identify the appendix. Which structure do you follow to locate it reliably?",
                    emojiIcon = "🧭",
                    choices = listOf(
                        SurgeryChoice("Trace the taeniae coli of the cecum to their convergence", true, "Correct — the taeniae coli converge at the base of the appendix.", 10),
                        SurgeryChoice("Look for the gallbladder as a landmark", false, "Wrong quadrant entirely — this will not help locate the appendix.", -5),
                        SurgeryChoice("Follow the terminal ileum blindly", false, "Can help orient but is not the most reliable landmark for the appendiceal base.", 0)
                    )
                ),
                SurgeryStep(
                    id = "step3",
                    stepNumber = 3,
                    instruction = "Secure and divide the mesoappendix containing the appendiceal artery.",
                    emojiIcon = "✂️",
                    timeLimitSeconds = 30,
                    choices = listOf(
                        SurgeryChoice("Use energy device (e.g., bipolar/harmonic) to seal and divide", true, "Correct — controls the appendiceal artery reliably before division.", 10),
                        SurgeryChoice("Divide the mesoappendix with scissors, no hemostasis first", false, "This risks uncontrolled bleeding from the appendiceal artery.", -10),
                        SurgeryChoice("Skip mesoappendix, go straight for the base", false, "Unsafe — the vascular supply must be controlled first.", -10)
                    )
                ),
                SurgeryStep(
                    id = "step4",
                    stepNumber = 4,
                    instruction = "Divide the appendiceal base. How do you proceed?",
                    emojiIcon = "🪢",
                    choices = listOf(
                        SurgeryChoice("Apply endoloop or stapler across a healthy base, then divide", true, "Correct — ensures a secure, tension-free closure of the cecal stump.", 10),
                        SurgeryChoice("Divide the base first, then try to close it", false, "Wrong order — risks contamination and an insecure stump.", -10),
                        SurgeryChoice("Apply the stapler across clearly inflamed cecal wall", false, "Stapling through friable, inflamed tissue risks a leak — should include a small margin of healthy tissue.", -5)
                    )
                ),
                SurgeryStep(
                    id = "step5",
                    stepNumber = 5,
                    instruction = "Final steps before closing.",
                    emojiIcon = "🧴",
                    choices = listOf(
                        SurgeryChoice("Extract specimen in a retrieval bag, irrigate, inspect for hemostasis, then close ports", true, "Correct — retrieval bag prevents wound contamination; irrigation clears contamination; hemostasis check prevents postop bleeding.", 10),
                        SurgeryChoice("Remove the specimen directly through the port without a bag", false, "Increases risk of wound infection/seeding, especially with a perforated or gangrenous appendix.", -5),
                        SurgeryChoice("Close ports immediately without inspecting for bleeding", false, "Skipping the final hemostasis check risks a missed postoperative bleed.", -10)
                    )
                )
            ),
            successSummary = "Clean laparoscopic appendectomy completed with good hemostasis and no contamination. " +
                "Patient can expect a short recovery with early discharge likely.",
            complicationSummary = "The procedure was completed, but errors along the way increase the risk of " +
                "postoperative bleeding, infection, or stump leak. Review the feedback on each step below."
        ),
        SurgeryProcedure(
            id = "lap_chole",
            title = "Laparoscopic Cholecystectomy",
            specialty = "General Surgery",
            difficulty = Difficulty.MODERATE,
            briefing = "45-year-old female with recurrent biliary colic and gallstones confirmed on ultrasound. " +
                "Proceeding to laparoscopic cholecystectomy.",
            patientContext = "Patient supine, reverse Trendelenburg with slight left tilt. Four-port technique.",
            steps = listOf(
                SurgeryStep(
                    id = "c_step1",
                    stepNumber = 1,
                    instruction = "Retract the gallbladder to expose Calot's triangle. Where do you grasp it?",
                    emojiIcon = "🫙",
                    choices = listOf(
                        SurgeryChoice("Grasp the fundus and retract cephalad, retract infundibulum laterally", true, "Correct — this classic two-handed retraction opens up Calot's triangle for safe dissection.", 10),
                        SurgeryChoice("Grasp only the fundus and pull straight up", false, "Insufficient exposure — Calot's triangle will not be adequately opened.", -5),
                        SurgeryChoice("Skip retraction and begin dissecting immediately", false, "Working without exposure dramatically increases the risk of bile duct injury.", -10)
                    )
                ),
                SurgeryStep(
                    id = "c_step2",
                    stepNumber = 2,
                    instruction = "Before dividing any structures, what safety step should you perform?",
                    emojiIcon = "🛑",
                    choices = listOf(
                        SurgeryChoice("Achieve the Critical View of Safety (CVS)", true, "Correct — CVS confirms only two structures (cystic duct and artery) enter the gallbladder, before dividing anything.", 15),
                        SurgeryChoice("Proceed directly to clip and divide the first tubular structure seen", false, "This is a leading cause of bile duct injury — the structure must be confirmed first.", -15),
                        SurgeryChoice("Perform an intraoperative cholangiogram routinely for every case", false, "Not wrong in principle, but not a substitute for establishing the Critical View of Safety, and not routinely required in straightforward cases.", 0)
                    )
                ),
                SurgeryStep(
                    id = "c_step3",
                    stepNumber = 3,
                    instruction = "Critical View of Safety confirmed. Clip and divide the cystic duct and artery.",
                    emojiIcon = "📎",
                    choices = listOf(
                        SurgeryChoice("Place clips proximally and distally, then divide between them", true, "Correct — standard safe technique once CVS is confirmed.", 10),
                        SurgeryChoice("Divide first, place clips after", false, "Uncontrolled division risks bleeding or bile leak.", -10),
                        SurgeryChoice("Use cautery to divide the cystic artery without clipping", false, "Energy alone is not reliable hemostasis for an arterial structure — clips are indicated.", -10)
                    )
                ),
                SurgeryStep(
                    id = "c_step4",
                    stepNumber = 4,
                    instruction = "Dissect the gallbladder off the liver bed.",
                    emojiIcon = "🔪",
                    choices = listOf(
                        SurgeryChoice("Dissect in the correct plane close to the gallbladder wall using cautery", true, "Correct — staying on the gallbladder wall avoids injury to the liver parenchyma and bleeding.", 10),
                        SurgeryChoice("Dissect deep into the liver parenchyma for a wider margin", false, "Unnecessary and causes liver bleeding — stay in the proper plane.", -10),
                        SurgeryChoice("Pull the gallbladder off sharply without cautery", false, "Risks bleeding from the liver bed without hemostatic control.", -5)
                    )
                ),
                SurgeryStep(
                    id = "c_step5",
                    stepNumber = 5,
                    instruction = "Final steps before closing.",
                    emojiIcon = "🧴",
                    choices = listOf(
                        SurgeryChoice("Inspect clips and liver bed for hemostasis, extract specimen in a bag, close ports", true, "Correct sequence — confirms hemostasis and prevents wound contamination from stones/bile.", 10),
                        SurgeryChoice("Close immediately once gallbladder is free, skip final inspection", false, "Skipping inspection risks missing a slipped clip or ongoing bleeding.", -10),
                        SurgeryChoice("Extract the gallbladder without a retrieval bag", false, "Risks spilling bile/stones into the wound.", -5)
                    )
                )
            ),
            successSummary = "Cholecystectomy completed safely with the Critical View of Safety achieved before " +
                "any structure was divided — the single most important step for avoiding bile duct injury.",
            complicationSummary = "The gallbladder was removed, but shortcuts taken along the way increase the risk " +
                "of bile duct injury, bleeding, or bile leak. Review the feedback on each step below."
        ),
        SurgeryProcedure(
            id = "wound_suturing",
            title = "Basic Wound Suturing",
            specialty = "Emergency Medicine / Basic Skills",
            difficulty = Difficulty.EASY,
            briefing = "28-year-old with a 4cm clean linear laceration on the forearm from a glass edge, " +
                "presenting within 2 hours of injury.",
            patientContext = "Wound has been irrigated. Local anesthesia already administered.",
            steps = listOf(
                SurgeryStep(
                    id = "w_step1",
                    stepNumber = 1,
                    instruction = "Before suturing, what must you confirm about the wound?",
                    emojiIcon = "🔎",
                    choices = listOf(
                        SurgeryChoice("Explore for foreign bodies, tendon/nerve/vessel injury, and adequate hemostasis", true, "Correct — a thorough exploration prevents missed injuries and infection from retained debris.", 10),
                        SurgeryChoice("Assume it's superficial since it looks clean", false, "Visual inspection alone can miss deeper structural injury.", -10),
                        SurgeryChoice("Apply sutures immediately to save time", false, "Skipping exploration risks closing over a foreign body or missed injury.", -10)
                    )
                ),
                SurgeryStep(
                    id = "w_step2",
                    stepNumber = 2,
                    instruction = "Choose the suturing technique for this simple linear laceration.",
                    emojiIcon = "🪡",
                    choices = listOf(
                        SurgeryChoice("Simple interrupted sutures", true, "Correct — ideal for a straightforward, low-tension linear wound.", 10),
                        SurgeryChoice("Purse-string suture", false, "Not appropriate for a linear wound — used for different indications (e.g., drain sites, some circular defects).", -5),
                        SurgeryChoice("Leave it open to heal by secondary intention", false, "Not appropriate for a clean laceration seen early with good approximation potential.", -5)
                    )
                ),
                SurgeryStep(
                    id = "w_step3",
                    stepNumber = 3,
                    instruction = "How do you place each suture for good approximation?",
                    emojiIcon = "📐",
                    choices = listOf(
                        SurgeryChoice("Evert the wound edges with symmetric bites on each side", true, "Correct — everted edges heal with a flatter, less noticeable scar.", 10),
                        SurgeryChoice("Invert the wound edges", false, "Inverted edges heal poorly and leave a depressed scar.", -10),
                        SurgeryChoice("Use asymmetric bites, larger on one side", false, "Causes uneven closure and puckering of the wound edge.", -5)
                    )
                ),
                SurgeryStep(
                    id = "w_step4",
                    stepNumber = 4,
                    instruction = "Wound closed. What do you advise for follow-up?",
                    emojiIcon = "📋",
                    choices = listOf(
                        SurgeryChoice("Dress the wound, advise on suture removal timing, and provide wound care instructions", true, "Correct — forearm sutures are typically removed in about 7-10 days with proper aftercare instructions.", 10),
                        SurgeryChoice("Tell the patient sutures never need to be removed", false, "Incorrect — non-absorbable skin sutures need timely removal.", -10),
                        SurgeryChoice("No follow-up instructions needed", false, "Patients need clear wound care and follow-up guidance to prevent infection or dehiscence.", -10)
                    )
                )
            ),
            successSummary = "Wound closed with well-approximated, everted edges and appropriate aftercare instructions given.",
            complicationSummary = "The wound was closed, but technique errors may lead to poor cosmetic outcome, " +
                "infection, or dehiscence. Review the feedback on each step below."
        )
    )

    fun getById(id: String): SurgeryProcedure? = procedures.find { it.id == id }
}
