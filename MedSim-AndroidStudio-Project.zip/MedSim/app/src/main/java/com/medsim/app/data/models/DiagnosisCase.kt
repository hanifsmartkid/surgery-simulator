package com.medsim.app.data.models

/**
 * A single ordered lab/imaging test the student can "order" during a case.
 * `resultText` is only revealed after the student chooses to order it,
 * and ordering unnecessary tests costs points (mirrors real stewardship of resources).
 */
data class DiagnosticTest(
    val id: String,
    val name: String,
    val resultText: String,
    val isEssential: Boolean,
    val costPoints: Int = 5
)

data class VitalSigns(
    val temperatureC: String,
    val heartRateBpm: String,
    val bloodPressure: String,
    val respiratoryRate: String,
    val spo2: String
)

data class PatientInfo(
    val name: String,
    val age: Int,
    val gender: String,
    val chiefComplaint: String,
    val historyOfPresentIllness: String,
    val pastMedicalHistory: String,
    val vitals: VitalSigns
)

enum class Difficulty { EASY, MODERATE, HARD }

/**
 * A full diagnostic scenario. The student reviews the patient info, reads
 * physical exam findings, selectively orders tests, and then submits a
 * final diagnosis from a list of plausible differentials.
 */
data class DiagnosisCase(
    val id: String,
    val title: String,
    val difficulty: Difficulty,
    val specialty: String,
    val patient: PatientInfo,
    val physicalExamFindings: List<String>,
    val availableTests: List<DiagnosticTest>,
    val differentialOptions: List<String>, // includes the correct answer, shuffled at display time
    val correctDiagnosis: String,
    val teachingPoints: List<String>,
    val redFlags: List<String> = emptyList()
)

/** Result of a completed diagnosis attempt, used for the summary screen. */
data class DiagnosisAttemptResult(
    val case: DiagnosisCase,
    val orderedTestIds: List<String>,
    val selectedDiagnosis: String,
    val wasCorrect: Boolean,
    val score: Int,
    val maxScore: Int
)
