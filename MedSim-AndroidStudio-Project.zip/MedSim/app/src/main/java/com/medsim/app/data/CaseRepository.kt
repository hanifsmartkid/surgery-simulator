package com.medsim.app.data

import com.medsim.app.data.models.*

/**
 * In-memory bank of training cases. In a production build this would be
 * loaded from a JSON asset or a remote content service so faculty could
 * update cases without shipping a new APK.
 */
object CaseRepository {

    val cases: List<DiagnosisCase> = listOf(
        DiagnosisCase(
            id = "appendicitis_01",
            title = "Right Lower Quadrant Pain",
            difficulty = Difficulty.EASY,
            specialty = "General Surgery",
            patient = PatientInfo(
                name = "J. Martinez",
                age = 22,
                gender = "Male",
                chiefComplaint = "Abdominal pain for 18 hours, worsening.",
                historyOfPresentIllness = "Pain began periumbilically and migrated to the right lower " +
                    "quadrant over the last 12 hours. Associated with anorexia, low-grade fever, and " +
                    "one episode of vomiting. Pain worsens with movement.",
                pastMedicalHistory = "No significant past medical history. No prior surgeries.",
                vitals = VitalSigns(
                    temperatureC = "38.1°C",
                    heartRateBpm = "102",
                    bloodPressure = "124/78",
                    respiratoryRate = "18",
                    spo2 = "99%"
                )
            ),
            physicalExamFindings = listOf(
                "Tenderness at McBurney's point",
                "Positive Rovsing's sign",
                "Voluntary guarding, no rebound yet",
                "Psoas sign positive"
            ),
            availableTests = listOf(
                DiagnosticTest("cbc", "Complete Blood Count", "WBC 14,200/µL with neutrophilia", true),
                DiagnosticTest("us_abd", "Abdominal Ultrasound", "Non-compressible, dilated appendix (9mm) with periappendiceal fluid", true),
                DiagnosticTest("ct_abd", "CT Abdomen/Pelvis", "Dilated appendix with wall thickening and fat stranding, no perforation", true),
                DiagnosticTest("urinalysis", "Urinalysis", "Unremarkable, no signs of UTI", false),
                DiagnosticTest("hcg", "Urine β-hCG", "Negative", true),
                DiagnosticTest("xray_chest", "Chest X-ray", "No acute cardiopulmonary process", false)
            ),
            differentialOptions = listOf(
                "Acute appendicitis",
                "Ovarian torsion",
                "Ectopic pregnancy",
                "Gastroenteritis",
                "Mesenteric adenitis"
            ),
            correctDiagnosis = "Acute appendicitis",
            teachingPoints = listOf(
                "Classic migratory pain (periumbilical → RLQ) is highly suggestive of appendicitis.",
                "Urine β-hCG should be ordered in any female of reproductive age with lower abdominal pain before assuming appendicitis.",
                "Ultrasound is a good first-line imaging choice in young patients to limit radiation exposure; CT is more sensitive/specific."
            ),
            redFlags = listOf("Rebound tenderness or rigidity may indicate perforation — reassess urgently if it develops.")
        ),
        DiagnosisCase(
            id = "stemi_01",
            title = "Crushing Chest Pain",
            difficulty = Difficulty.MODERATE,
            specialty = "Cardiology / Emergency Medicine",
            patient = PatientInfo(
                name = "R. Osei",
                age = 58,
                gender = "Male",
                chiefComplaint = "Severe crushing chest pain radiating to the left arm, started 40 minutes ago.",
                historyOfPresentIllness = "Sudden onset substernal chest pressure at rest, 8/10, radiating to " +
                    "left jaw and arm, associated with diaphoresis and nausea. No relief with rest.",
                pastMedicalHistory = "Hypertension, type 2 diabetes, 30 pack-year smoking history.",
                vitals = VitalSigns(
                    temperatureC = "36.9°C",
                    heartRateBpm = "110",
                    bloodPressure = "150/95",
                    respiratoryRate = "22",
                    spo2 = "95%"
                )
            ),
            physicalExamFindings = listOf(
                "Diaphoretic, anxious-appearing",
                "S4 gallop on auscultation",
                "No jugular venous distension",
                "Lungs clear bilaterally"
            ),
            availableTests = listOf(
                DiagnosticTest("ecg", "12-lead ECG", "ST-segment elevation in leads II, III, aVF (2-3mm)", true),
                DiagnosticTest("troponin", "Troponin I", "Elevated at 2.1 ng/mL (rising)", true),
                DiagnosticTest("cxr", "Chest X-ray", "No widened mediastinum, no pulmonary edema", true),
                DiagnosticTest("d_dimer", "D-dimer", "Not clinically indicated in this presentation", false),
                DiagnosticTest("bnp", "BNP", "Mildly elevated, non-specific", false),
                DiagnosticTest("echo", "Bedside Echocardiogram", "Inferior wall hypokinesis", true)
            ),
            differentialOptions = listOf(
                "ST-elevation myocardial infarction (inferior)",
                "Aortic dissection",
                "Pulmonary embolism",
                "Unstable angina",
                "Pericarditis"
            ),
            correctDiagnosis = "ST-elevation myocardial infarction (inferior)",
            teachingPoints = listOf(
                "ST elevation in II, III, aVF localizes to the inferior wall, typically supplied by the RCA.",
                "Time is muscle — the goal is door-to-balloon time under 90 minutes for primary PCI.",
                "Always rule out aortic dissection before giving anticoagulants/thrombolytics if the story or exam suggests it (unequal pulses, tearing pain, widened mediastinum)."
            ),
            redFlags = listOf("Hypotension with an inferior MI raises concern for right ventricular involvement — avoid nitrates.")
        ),
        DiagnosisCase(
            id = "dka_01",
            title = "Confused Diabetic Patient",
            difficulty = Difficulty.HARD,
            specialty = "Endocrinology / Emergency Medicine",
            patient = PatientInfo(
                name = "S. Chen",
                age = 19,
                gender = "Female",
                chiefComplaint = "Brought in by family for confusion and rapid breathing over the last day.",
                historyOfPresentIllness = "Three days of nausea, vomiting, and excessive thirst/urination. " +
                    "Family reports she ran out of insulin last week. Now lethargic with deep, labored breathing.",
                pastMedicalHistory = "Type 1 diabetes mellitus, diagnosed age 12.",
                vitals = VitalSigns(
                    temperatureC = "37.2°C",
                    heartRateBpm = "124",
                    bloodPressure = "98/62",
                    respiratoryRate = "32 (deep, Kussmaul pattern)",
                    spo2 = "98%"
                )
            ),
            physicalExamFindings = listOf(
                "Dry mucous membranes, poor skin turgor",
                "Fruity odor on breath",
                "Lethargic but arousable",
                "Diffuse mild abdominal tenderness, no rebound"
            ),
            availableTests = listOf(
                DiagnosticTest("glucose", "Point-of-care Glucose", "612 mg/dL", true),
                DiagnosticTest("vbg", "Venous Blood Gas", "pH 7.12, HCO3 9 mEq/L", true),
                DiagnosticTest("ketones", "Serum/Urine Ketones", "Large ketones present", true),
                DiagnosticTest("bmp", "Basic Metabolic Panel", "K+ 5.6, Na+ 131, anion gap 24", true),
                DiagnosticTest("ct_head", "CT Head", "No acute intracranial abnormality", false),
                DiagnosticTest("blood_cx", "Blood Cultures", "Pending — send if infectious source suspected", false)
            ),
            differentialOptions = listOf(
                "Diabetic ketoacidosis",
                "Hyperosmolar hyperglycemic state",
                "Sepsis",
                "Alcoholic ketoacidosis",
                "Salicylate toxicity"
            ),
            correctDiagnosis = "Diabetic ketoacidosis",
            teachingPoints = listOf(
                "The triad of hyperglycemia, high anion-gap metabolic acidosis, and ketosis defines DKA.",
                "Kussmaul breathing is a compensatory response to metabolic acidosis, not a primary respiratory problem.",
                "Potassium is often high on initial labs despite total-body depletion — insulin therapy will drive it down further, so it must be monitored closely and repleted."
            ),
            redFlags = listOf("Missed insulin doses are the most common precipitant in known type 1 diabetics — always ask about adherence and look for an infectious trigger.")
        ),
        DiagnosisCase(
            id = "pe_01",
            title = "Sudden Shortness of Breath After Flight",
            difficulty = Difficulty.MODERATE,
            specialty = "Pulmonology / Emergency Medicine",
            patient = PatientInfo(
                name = "A. Novak",
                age = 45,
                gender = "Female",
                chiefComplaint = "Sudden shortness of breath and right-sided chest pain since landing from a long flight.",
                historyOfPresentIllness = "Developed acute pleuritic chest pain and dyspnea two hours after " +
                    "a 10-hour international flight. Denies cough or fever. Mild right calf swelling noticed yesterday.",
                pastMedicalHistory = "Oral contraceptive use. No prior clots. Non-smoker.",
                vitals = VitalSigns(
                    temperatureC = "37.0°C",
                    heartRateBpm = "118",
                    bloodPressure = "108/70",
                    respiratoryRate = "26",
                    spo2 = "91% on room air"
                )
            ),
            physicalExamFindings = listOf(
                "Tachypneic, mild respiratory distress",
                "Right calf swollen and tender compared to left",
                "Lungs clear to auscultation",
                "No jugular venous distension"
            ),
            availableTests = listOf(
                DiagnosticTest("d_dimer", "D-dimer", "Elevated at 2400 ng/mL", true),
                DiagnosticTest("ctpa", "CT Pulmonary Angiogram", "Filling defect in right main pulmonary artery", true),
                DiagnosticTest("ecg", "12-lead ECG", "Sinus tachycardia, S1Q3T3 pattern", true),
                DiagnosticTest("us_leg", "Lower Extremity Doppler Ultrasound", "Non-compressible right popliteal vein — DVT confirmed", true),
                DiagnosticTest("troponin", "Troponin I", "Mildly elevated, suggests RV strain", true),
                DiagnosticTest("cxr", "Chest X-ray", "Unremarkable", false)
            ),
            differentialOptions = listOf(
                "Pulmonary embolism",
                "Acute coronary syndrome",
                "Pneumothorax",
                "Panic attack",
                "Community-acquired pneumonia"
            ),
            correctDiagnosis = "Pulmonary embolism",
            teachingPoints = listOf(
                "Prolonged immobility (long-haul flight) plus oral contraceptive use are classic VTE risk factors.",
                "S1Q3T3 is a classic but insensitive ECG finding suggestive of right heart strain from PE.",
                "A confirmed DVT plus a matching clinical picture may be enough to start treatment without waiting for CTPA in some protocols — but imaging confirms the diagnosis and guides risk stratification."
            ),
            redFlags = listOf("Hypotension or syncope with suspected PE suggests a massive/high-risk PE requiring urgent escalation.")
        )
    )

    fun getById(id: String): DiagnosisCase? = cases.find { it.id == id }
}
