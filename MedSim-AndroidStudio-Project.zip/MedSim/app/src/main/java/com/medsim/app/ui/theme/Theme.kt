package com.medsim.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = MedBlue,
    onPrimary = Color.White,
    secondary = MedTeal,
    background = MedBackground,
    surface = MedSurface,
    onSurface = MedOnSurface,
    error = MedRed
)

private val DarkColors = darkColorScheme(
    primary = MedBlue,
    secondary = MedTeal,
    error = MedRed
)

@Composable
fun MedSimTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MedSimTypography,
        content = content
    )
}
