package com.medsim.app.ui.screens.diagnosis

import androidx.lifecycle.ViewModel
import com.medsim.app.data.CaseRepository
import com.medsim.app.data.models.DiagnosisAttemptResult
import com.medsim.app.data.models.DiagnosisCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DiagnosisUiState(
    val case: DiagnosisCase? = null,
    val orderedTestIds: Set<String> = emptySet(),
    val shuffledDifferentials: List<String> = emptyList(),
    val selectedDiagnosis: String? = null,
    val submitted: Boolean = false,
    val result: DiagnosisAttemptResult? = null
)

class DiagnosisViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(DiagnosisUiState())
    val uiState: StateFlow<DiagnosisUiState> = _uiState.asStateFlow()

    fun loadCase(caseId: String) {
        val case = CaseRepository.getById(caseId) ?: return
        _uiState.value = DiagnosisUiState(
            case = case,
            shuffledDifferentials = case.differentialOptions.shuffled()
        )
    }

    fun toggleTest(testId: String) {
        val current = _uiState.value
        if (current.submitted) return
        val updated = if (current.orderedTestIds.contains(testId)) {
            current.orderedTestIds - testId
        } else {
            current.orderedTestIds + testId
        }
        _uiState.value = current.copy(orderedTestIds = updated)
    }

    fun selectDiagnosis(option: String) {
        if (_uiState.value.submitted) return
        _uiState.value = _uiState.value.copy(selectedDiagnosis = option)
    }

    fun submit() {
        val state = _uiState.value
        val case = state.case ?: return
        val selected = state.selectedDiagnosis ?: return

        val wasCorrect = selected == case.correctDiagnosis

        // Scoring: diagnosis correctness is worth the most; ordering essential tests
        // earns points, ordering non-essential tests costs a small penalty (stewardship).
        var score = if (wasCorrect) 60 else 0
        var maxScore = 60

        case.availableTests.forEach { test ->
            val ordered = state.orderedTestIds.contains(test.id)
            if (test.isEssential) {
                maxScore += 8
                if (ordered) score += 8
            } else {
                if (ordered) score -= 4
            }
        }
        score = score.coerceAtLeast(0)

        val result = DiagnosisAttemptResult(
            case = case,
            orderedTestIds = state.orderedTestIds.toList(),
            selectedDiagnosis = selected,
            wasCorrect = wasCorrect,
            score = score,
            maxScore = maxScore
        )

        _uiState.value = state.copy(submitted = true, result = result)
    }

    fun reset(caseId: String) {
        loadCase(caseId)
    }
}
