package com.medsim.app.ui.screens.surgery

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.medsim.app.data.SurgeryRepository
import com.medsim.app.data.models.Difficulty

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurgeryListScreen(
    onBack: () -> Unit,
    onSelectProcedure: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Surgery Simulator") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(SurgeryRepository.procedures) { procedure ->
                Card(
                    onClick = { onSelectProcedure(procedure.id) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = procedure.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${procedure.specialty} · ${difficultyLabel(procedure.difficulty)} · ${procedure.steps.size} steps",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = procedure.briefing, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

private fun difficultyLabel(difficulty: Difficulty): String = when (difficulty) {
    Difficulty.EASY -> "Easy"
    Difficulty.MODERATE -> "Moderate"
    Difficulty.HARD -> "Hard"
}
