# MedSim — Medical Diagnosis & Surgery Simulator (Android)

A training app for medical students built with **Kotlin + Jetpack Compose**. It has two modes:

1. **Diagnosis Simulator** — review a patient's history, vitals, and exam findings, selectively
   order labs/imaging, then submit a diagnosis from a list of differentials. Scored on
   diagnostic accuracy and appropriate test ordering (ordering unnecessary tests costs points,
   mirroring real resource stewardship). Includes teaching points and red flags after each case.
2. **Surgery Simulator** — step through an operative procedure (laparoscopic appendectomy,
   laparoscopic cholecystectomy, basic wound suturing) making the correct choice at each decision
   point, with immediate feedback and a scored summary at the end.

This is a **complete, working Android Studio project** — no placeholders. It compiles to a real
installable app once you build it locally (see below for why it wasn't pre-compiled here).

## ⚠️ Important disclaimer
This is an **educational training tool**, not a certified medical device and not a substitute for
supervised clinical training, licensed simulation software, or real patient care. Content is
simplified for teaching purposes — always defer to your institution's curriculum and clinical
supervisors.

## Why you build it yourself
Compiling a signed `.apk`/`.aab` requires the Android SDK, build tools, and Google's Maven
repositories, which aren't available in the environment that generated this project. Instead,
you get the full source — open it in Android Studio and it builds normally.

## Option A (recommended): Build the APK in the cloud via GitHub Actions — no install needed

This project includes `.github/workflows/build-apk.yml`, which builds a debug APK automatically
on GitHub's servers. To use it:

1. Create a free account at https://github.com if you don't have one.
2. Create a new **public or private** repository (e.g. `medsim-app`).
3. Upload this entire `MedSim` folder's contents to that repo. Easiest way with no command line:
   on the repo page, click **Add file → Upload files**, drag in everything from this zip, then
   commit to the `main` branch.
4. Go to the **Actions** tab of your repo. A workflow called "Build Debug APK" will run
   automatically (takes a few minutes).
5. When it finishes (green check), click into that run, scroll to **Artifacts**, and download
   `MedSim-debug-apk` — that's a zip containing `app-debug.apk`.
6. Transfer the `.apk` to your Android phone (email it to yourself, Google Drive, USB, etc.),
   open it, and allow "install from unknown sources" if prompted. That installs the app.

You can re-run the workflow anytime (Actions tab → Build Debug APK → **Run workflow**) after
making changes, e.g. adding more cases.

Note: this repo does not include Gradle wrapper binary files (`gradlew`/`gradle-wrapper.jar`) —
the workflow installs Gradle directly on the runner instead, so nothing extra is needed on your end.

## Option B: Build locally in Android Studio

1. Install **Android Studio** (Koala/2024.1 or newer) — it bundles the JDK and Android SDK.
2. Open Android Studio → **Open** → select the `MedSim` folder (this project root). If prompted
   about a missing Gradle wrapper, let Android Studio generate one automatically (it will offer to).
3. Let Gradle sync (downloads dependencies the first time — needs internet).
4. Click **Run ▶** with an emulator or a connected device (Android 7.0 / API 24+).
5. To produce an installable APK directly: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
   The output `.apk` appears under `app/build/outputs/apk/debug/`.

## Project structure

```
MedSim/
├── app/
│   └── src/main/java/com/medsim/app/
│       ├── MainActivity.kt              # Entry point, sets up theme + nav host
│       ├── data/
│       │   ├── models/                  # DiagnosisCase.kt, SurgeryProcedure.kt
│       │   ├── CaseRepository.kt        # 4 sample diagnosis cases
│       │   └── SurgeryRepository.kt     # 3 sample surgical procedures
│       └── ui/
│           ├── theme/                   # Compose Material3 theme
│           ├── navigation/NavGraph.kt   # Screen routing
│           └── screens/
│               ├── home/HomeScreen.kt
│               ├── diagnosis/           # List + interactive case screen + ViewModel
│               └── surgery/             # List + interactive step screen + ViewModel
└── README.md
```

## Included content (starter set)

**Diagnosis cases:** acute appendicitis, inferior STEMI, diabetic ketoacidosis, pulmonary embolism.
**Surgery procedures:** laparoscopic appendectomy, laparoscopic cholecystectomy, basic wound suturing.

## Extending it

- **Add a diagnosis case:** append a new `DiagnosisCase(...)` entry to `CaseRepository.kt`.
- **Add a surgery procedure:** append a new `SurgeryProcedure(...)` entry to `SurgeryRepository.kt`.
- **Load content from JSON/remote instead of hardcoding:** replace the repository objects with a
  loader (e.g. `kotlinx.serialization` + a `cases.json` asset, or a Retrofit call to a CMS) so
  faculty can update cases without shipping a new build.
- **Add images/diagrams:** the surgery steps currently use emoji as lightweight placeholders for
  illustrations — swap `emojiIcon` for an `Image`/`AsyncImage` (Coil) once you have real art or
  anatomical diagrams.
- **Persistence/progress tracking:** add Room or DataStore to save attempt history and scores
  per user across sessions.
- **Accounts/multi-user:** if this will be deployed to a class, consider Firebase Auth +
  Firestore to track cohort progress centrally.

## Known limitations (by design, given scope)

- Content is a small starter set (4 diagnosis cases, 3 procedures) meant to be extended.
- No backend/accounts — everything runs locally and state resets between app launches.
- Surgery "simulation" is decision-based (multiple choice at each step), not a 3D/haptic
  simulation — building true 3D haptic surgical simulation is a multi-year, specialized
  engineering effort (like real products such as Touch Surgery, Osso VR, or Fundamental
  Surgery) and out of scope for a single app project.
